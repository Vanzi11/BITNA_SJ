# Guia Ilustrado: Astrologia Coreana Saju (사주)

A astrologia coreana **Saju** (사주), também conhecida como "Quatro Pilares do Destino" (Four Pillars of Destiny), é um sistema tradicional de adivinhação e leitura de fortuna que tem raízes na metafísica chinesa (BaZi), mas foi adaptado e praticado na Coreia por centenas de anos. O termo "Sa" significa quatro e "Ju" significa pilares, referindo-se ao ano, mês, dia e hora de nascimento de uma pessoa.

Este documento compila informações, imagens e links de vídeos para ajudá-lo a entender melhor o sistema Saju.

## O que é o Saju?

O sistema Saju analisa a energia do momento em que você nasceu, utilizando o calendário lunar e a teoria dos Cinco Elementos (Yin e Yang, Madeira, Fogo, Terra, Metal e Água). Cada pilar é representado por dois caracteres (um Tronco Celeste e um Ramo Terrestre), totalizando oito caracteres (Saju Palja - 사주팔자) que formam o mapa do seu destino [1] [2].

## Galeria de Imagens

Abaixo, você encontrará uma coleção de imagens que ilustram os conceitos do Saju, incluindo gráficos de leitura, os cinco elementos, troncos celestes e representações culturais de adivinhos na Coreia.

### 1. Gráficos de Leitura e Cartas de Nascimento
As imagens a seguir mostram como uma carta de Saju é estruturada, com os quatro pilares (Ano, Mês, Dia, Hora) e os elementos correspondentes.

![Gráfico de Leitura Saju](01_saju_reading_chart.png)
*Fonte: K-Saju*

![Carta de Nascimento Saju](02_saju_birth_chart.png)
*Fonte: K-Saju*

![Exemplo de Carta Completa](05_saju_chart_example.jpeg)
*Fonte: Reddit*

![Diagrama dos Pilares](13_saju_pillars_diagram.png)
*Fonte: Medium*

### 2. Os Cinco Elementos e Troncos Celestes
A base do Saju é a interação entre os elementos. As imagens abaixo ilustram a tabela dos Dez Troncos Celestes (천간) e a relação de geração e controle entre Madeira, Fogo, Terra, Metal e Água.

![Tabela de Troncos Celestes](08_heavenly_stems_chart.png)
*Fonte: K-Saju*

![Tabela Detalhada dos Troncos](11_ten_stems_table.png)
*Fonte: K-Saju*

![Interação dos Cinco Elementos](10_saju_yinyang_elements.jpg)
*Fonte: Web*

### 3. Prática Tradicional e Cultural na Coreia
O Saju é uma parte importante da cultura coreana, frequentemente associado a xamãs (Mudang) e adivinhos tradicionais. As imagens abaixo mostram o ambiente de leitura de fortuna na Coreia do Sul.

![Adivinhação na Coreia](06_korea_fortune_telling.jpg)
*Fonte: The Korea Herald*

![Rua de Adivinhos](07_saju_fortune_street.jpg)
*Fonte: Sofie to Korea*

![Leitura Xamânica](17_saju_shamanic.jpg)
*Fonte: Etsy*

### 4. Aplicativos e Serviços Modernos
Hoje, o Saju também é popularizado através de aplicativos móveis e serviços online, como visto nas imagens abaixo.

![Aplicativo Saju](15_saju_app.jpg)
*Fonte: Google Play*

![Cartas Saju](16_saju_cards.png)
*Fonte: Caret*

## Vídeos Explicativos sobre Saju

Para uma compreensão mais aprofundada e visual, aqui estão alguns vídeos em inglês e coreano (com legendas visuais) que explicam como o Saju funciona:

| Título do Vídeo | Canal / Fonte | Link |
| :--- | :--- | :--- |
| **What is Saju? Discover Korea's Fortune-Telling System!** | Canal no YouTube | [Assistir no YouTube](https://www.youtube.com/watch?v=58IVWiDz3HQ) |
| **How to Read Your Saju Palja (Korean Fortune Telling)** | Canal no YouTube | [Assistir no YouTube](https://www.youtube.com/watch?v=uT0sffmdwNM) |
| **Understanding Korean Saju, Fortune telling Method "Four Pillars of Destiny"** | Canal no YouTube | [Assistir no YouTube](https://www.youtube.com/watch?v=s-TynPeN0ko) |
| **How to Find Your Saju: Step-by-Step Guide** | TikTok (@jewelsjpj) | [Assistir no TikTok](https://www.tiktok.com/@jewelsjpj/video/7546720949953957150) |
| **Korean Shamanism: Fortune-Telling & Saju** | Canal no YouTube | [Assistir no YouTube](https://www.youtube.com/watch?v=HqEaiX0YrqQ) |

## Referências

[1] [K-Saju: A Professional Guide to Korean Astrology](https://k-saju.co.kr/)
[2] [Best of Korea: Saju Readings Guide](https://bestofkorea.com/saju-reading-guide-to-korean-fortune-telling/)
