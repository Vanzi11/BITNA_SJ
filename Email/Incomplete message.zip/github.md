repo: Vanzi11/BITNA_SJ
branch: main
path: empresa/marca (brand reference only — email is a new standalone deliverable)

## Last sync
date: 2026-08-07T02:51:46Z

### Updated in this project
- Built the "relatório pronto" delivery email using the brand's institutional palette (Hanji White, Soft Charcoal, Ink Blue, Matte Bronze, Seal Red) and typography (Playfair Display / Georgia serif + Inter / Arial sans) from `empresa/marca/VISUAL_LANGUAGE.md`.
- Copy tone follows `empresa/GUIA_DE_VOZ.md` and `empresa/marca/EDITORIAL_SYSTEM.md` (sober, welcoming, no mystical/sales language).
- Recreated the BITNA SAJU wordmark + red 빛나 seal as bulletproof text/table markup (no hosted image) per uploads/logo_hero_branco.png reference.

## Screen map
| Project screen | Repo source |
|---|---|
| bitna-saju-relatorio-pronto.html | empresa/marca/VISUAL_LANGUAGE.md, empresa/GUIA_DE_VOZ.md, empresa/marca/EDITORIAL_SYSTEM.md, empresa/EMPRESA.md |
